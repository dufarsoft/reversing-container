#ifndef _SCRIPT_API_H
#define _SCRIPT_API_H

#include "_plugins.h"

#define SCRIPT_EXPORT PLUG_IMPEXP

#endif //_SCRIPT_API_H